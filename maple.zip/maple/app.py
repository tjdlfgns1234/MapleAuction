from flask import Flask, render_template, jsonify, request
import pymysql
from db.database import *

# 플라스크 서버 선언
app = Flask(__name__)

base_use_dict = get_base_use()
@app.route('/Base/use', methods=['POST'])
def Post_Base_Use():
    global base_use_dict
    data = request.json
    # 각 column의 이름 정해줘야됨

    for item in data:
        Use_ID, Name, Image_url, Description = item.values()
        base_use_dict[Use_ID] = {
            "Use_ID": Use_ID,
            "Name": Name,
            "Image_url": Image_url,
            "Description": Description,
        }
    return jsonify({"message": "Items updated successfully"}), 200


# Post한 데이터 GET 해와서 json 형식으로 변환.
@app.route('/Base/use', methods=['GET'])
def Get_Base_Use():
    return jsonify(base_use_dict), 200

base_etc_dict = get_base_etc()
@app.route('/Base/etc', methods=['POST'])
def Post_Base_Etc():
    global base_etc_dict
    data = request.json
    # 각 column의 이름 정해줘야됨

    for item in data:
        Etc_ID, Name, Image_url, Description = item.values()
        base_etc_dict[Etc_ID] = {
            "Etc_ID": Etc_ID,
            "Name": Name,
            "Image_url": Image_url,
            "Description": Description,
        }
    return jsonify({"message": "Items updated successfully"}), 200


# Post한 데이터 GET 해와서 json 형식으로 변환.
@app.route('/Base/etc', methods=['GET'])
def Get_Base_Etc():
    return jsonify(base_etc_dict), 200

base_weapon_dict = get_base_weapon()
# 쿼리로 불러오는 데이터 딕셔너리 변환 했으면, 각 필요한 column 설정해서 데이터 Post
@app.route('/Base/Weapon', methods=['POST'])
def Post_Base_Weapon():
    global base_weapon_dict
    data = request.json
    for item in data:
        Base_Status_ID, Image_url, name, STR_, DEX_, INT_, LUK_, Attack_Power, Magic_Att, Boss_Damage, Ignored_DEF = item.values()

        # item_id, name, class_, type_, img_url = item.values()
        base_weapon_dict[Base_Status_ID] = {"Image_url": Image_url,
                                            "name": name,
                                            "STR_": STR_,
                                            "DEX_": DEX_,
                                            "INT_": INT_,
                                            "LUK_": LUK_,
                                            "Attack_Power": Attack_Power,
                                            "Magic_Att": Magic_Att,
                                            "Boss_Damage": Boss_Damage,
                                            "Ignored_DEF": Ignored_DEF,
                                            }
    return jsonify({"message": "Items updated successfully"}), 200


# Post한 데이터 GET 해와서 json 형식으로 변환.
@app.route('/Base/Weapon', methods=['GET'])
def Get_Base_Weapon():
    return jsonify(base_weapon_dict), 200


weapon_scania_dict = get_scania_weapon()

# 쿼리로 불러오는 데이터 딕셔너리 변환 했으면, 각 필요한 column 설정해서 데이터 Post
@app.route('/Scania/Weapon', methods=['POST'])
def Post_Scania_Weapon():
    global weapon_scania_dict
    data = request.json
    for item in data:
        Market_Weapon_ID, Image, name, Price, Class, Star_force, STR_, DEX_, INT_, LUK_, All_stat, Attack_Power, Magic_Att, Damage, Boss_Damage, Rank_, Potential1, Potential2, Potential3, Add_Rank, Add_Potential1, Add_Potential2, Add_Potential3 = item.values()

        # item_id, name, class_, type_, img_url = item.values()
        weapon_scania_dict[Market_Weapon_ID] = {"Image": Image,
                                                "name": name,
                                                "Price": Price,
                                                "Class": Class,
                                                "Star_force": Star_force,
                                                "STR_": STR_,
                                                "DEX_": DEX_,
                                                "INT_": INT_,
                                                "LUK_": LUK_,
                                                "All_stat": All_stat,
                                                "Attack_Power": Attack_Power,
                                                "Magic_Att": Magic_Att,
                                                "Damage": Damage,
                                                "Boss_Damage": Boss_Damage,
                                                "Rank": Rank_,
                                                "Potential1": Potential1,
                                                "Potential2": Potential2,
                                                "Potential3": Potential3,
                                                "Add_Rank": Add_Rank,
                                                "Add_Potential1": Add_Potential1,
                                                "Add_Potential2": Add_Potential2,
                                                "Add_Potential3": Add_Potential3
                                                }
    return jsonify({"message": "Items updated successfully"}), 200


# Post한 데이터 GET 해와서 json 형식으로 변환.
@app.route('/Scania/Weapon', methods=['GET'])
def Get_Scania_Weapon():
    return jsonify(weapon_scania_dict), 200


weapon_aurora_dict = get_aurora_weapon()


# 쿼리로 불러오는 데이터 딕셔너리 변환 했으면, 각 필요한 column 설정해서 데이터 Post
@app.route('/Aurora/Weapon', methods=['POST'])
def Post_Aurora_Weapon():
    global weapon_aurora_dict
    data = request.json
    for item in data:
        Market_Weapon_ID, Image, name, Price, Class, Star_force, STR_, DEX_, INT_, LUK_, All_stat, Attack_Power, Magic_Att, Damage, Boss_Damage, Rank_, Potential1, Potential2, Potential3, Add_Rank, Add_Potential1, Add_Potential2, Add_Potential3 = item.values()

        # item_id, name, class_, type_, img_url = item.values()
        weapon_aurora_dict[Market_Weapon_ID] = {"Image": Image,
                                                "name": name,
                                                "Price": Price,
                                                "Class": Class,
                                                "Star_force": Star_force,
                                                "STR_": STR_,
                                                "DEX_": DEX_,
                                                "INT_": INT_,
                                                "LUK_": LUK_,
                                                "All_stat": All_stat,
                                                "Attack_Power": Attack_Power,
                                                "Magic_Att": Magic_Att,
                                                "Damage": Damage,
                                                "Boss_Damage": Boss_Damage,
                                                "Rank": Rank_,
                                                "Potential1": Potential1,
                                                "Potential2": Potential2,
                                                "Potential3": Potential3,
                                                "Add_Rank": Add_Rank,
                                                "Add_Potential1": Add_Potential1,
                                                "Add_Potential2": Add_Potential2,
                                                "Add_Potential3": Add_Potential3
                                                }
    return jsonify({"message": "Items updated successfully"}), 200


# Post한 데이터 GET 해와서 json 형식으로 변환.
@app.route('/Aurora/Weapon', methods=['GET'])
def Get_Aurora_Weapon():
    return jsonify(weapon_aurora_dict), 200


# db의 딕셔너리를 불러와
armor_scania_dict = get_scania_armor()


####### Armor 데이터
# 쿼리로 불러오는 데이터 딕셔너리 변환 했으면, 각 필요한 column 설정해서 데이터 Post
@app.route('/Scania/Armor', methods=['POST'])
def Post_Scania_Armor():
    global armor_scania_dict
    data = request.json
    for item in data:
        AAO_Market_Armor_ID, Image, name, Price, Class, Star_force, STR_, DEX_, INT_, LUK_, All_stat, Attack_Power, Magic_Att, Rank_, Potential1, Potential2, Potential3, Add_Rank, Add_Potential1, Add_Potential2, Add_Potential3 = item.values()
        # item_id, name, class_, type_, img_url = item.values()
        armor_scania_dict[AAO_Market_Armor_ID] = {"Image": Image,
                                                  "name": name,
                                                  "Price": Price,
                                                  "Class": Class,
                                                  "Star_force": Star_force,
                                                  "STR_": STR_,
                                                  "DEX_": DEX_,
                                                  "INT_": INT_,
                                                  "LUK_": LUK_,
                                                  "All_stat": All_stat,
                                                  "Attack_Power": Attack_Power,
                                                  "Magic_Att": Magic_Att,
                                                  "Rank_": Rank_,
                                                  "Potential1": Potential1,
                                                  "Potential2": Potential2,
                                                  "Potential3": Potential3,
                                                  "Add_Rank": Add_Rank,
                                                  "Add_Potential1": Add_Potential1,
                                                  "Add_Potential2": Add_Potential2,
                                                  "Add_Potential3": Add_Potential3
                                                  }
    return jsonify({"message": "Items updated successfully"}), 200


# Post한 데이터 GET 해와서 json 형식으로 변환.
@app.route('/Scania/Armor', methods=['GET'])
def Get_Scania_Armor():
    return jsonify(armor_scania_dict), 200


armor_aurora_dict = get_aurora_armor()


####### Armor 데이터
# 쿼리로 불러오는 데이터 딕셔너리 변환 했으면, 각 필요한 column 설정해서 데이터 Post
@app.route('/Aurora/Armor', methods=['POST'])
def Post_Aurora_Armor():
    global armor_aurora_dict
    data = request.json
    for item in data:
        AAO_Market_Armor_ID, Image, name, Price, Class, Star_force, STR_, DEX_, INT_, LUK_, All_stat, Attack_Power, Magic_Att, Rank_, Potential1, Potential2, Potential3, Add_Rank, Add_Potential1, Add_Potential2, Add_Potential3 = item.values()
        # item_id, name, class_, type_, img_url = item.values()
        armor_aurora_dict[AAO_Market_Armor_ID] = {"Image": Image,
                                                  "name": name,
                                                  "Price": Price,
                                                  "Class": Class,
                                                  "Star_force": Star_force,
                                                  "STR_": STR_,
                                                  "DEX_": DEX_,
                                                  "INT_": INT_,
                                                  "LUK_": LUK_,
                                                  "All_stat": All_stat,
                                                  "Attack_Power": Attack_Power,
                                                  "Magic_Att": Magic_Att,
                                                  "Rank_": Rank_,
                                                  "Potential1": Potential1,
                                                  "Potential2": Potential2,
                                                  "Potential3": Potential3,
                                                  "Add_Rank": Add_Rank,
                                                  "Add_Potential1": Add_Potential1,
                                                  "Add_Potential2": Add_Potential2,
                                                  "Add_Potential3": Add_Potential3
                                                  }
    return jsonify({"message": "Items updated successfully"}), 200


# Post한 데이터 GET 해와서 json 형식으로 변환.
@app.route('/Aurora/Armor', methods=['GET'])
def Get_Aurora_Armor():
    return jsonify(armor_aurora_dict), 200


scania_use_items_dict = get_scania_use_items()


# Scania Use 데이터
# 쿼리로 불러오는 데이터 딕셔너리 변환 했으면, 각 필요한 column 설정해서 데이터 Post
@app.route('/Scania/use', methods=['POST'])
def Post_Scania_Use():
    global scania_use_items_dict
    data = request.json
    print(scania_use_items_dict)
    # 각 column의 이름 정해줘야됨

    for item in data:
        Market_Use_ID, Name, Image_url, Description, Price, Registration_date, Count = item.values()
        scania_use_items_dict[Market_Use_ID] = {
            "Market_Use_ID": Market_Use_ID,
            "Name": Name,
            "Image_url": Image_url,
            "Description": Description,
            "Price": Price,
            "Registration_date": Registration_date,
            "Count": Count
        }
    return jsonify({"message": "Items updated successfully"}), 200


# Post한 데이터 GET 해와서 json 형식으로 변환.
@app.route('/Scania/use', methods=['GET'])
def Get_Scania_Use():
    return jsonify(scania_use_items_dict), 200


aurora_use_items_dict = get_aurora_use_items()


# Aurora Use 데이터
# 쿼리로 불러오는 데이터 딕셔너리 변환 했으면, 각 필요한 column 설정해서 데이터 Post
@app.route('/Aurora/use', methods=['POST'])
def Post_Aurora_Use():
    global aurora_use_items_dict
    data = request.json
    print(aurora_use_items_dict)
    # 각 column의 이름 정해줘야됨

    for item in data:
        Market_Use_ID, Name, Image_url, Description, Price, Registration_date, Count = item.values()
        aurora_use_items_dict[Market_Use_ID] = {
            "Market_Use_ID": Market_Use_ID,
            "Name": Name,
            "Image_url": Image_url,
            "Description": Description,
            "Price": Price,
            "Registration_date": Registration_date,
            "Count": Count
        }
    return jsonify({"message": "Items updated successfully"}), 200


# Post한 데이터 GET 해와서 json 형식으로 변환.
@app.route('/Aurora/use', methods=['GET'])
def Get_Aurora_Use():
    return jsonify(aurora_use_items_dict), 200


scania_etc_items_dict = get_scania_etc_items()


# Scania Use 데이터
# 쿼리로 불러오는 데이터 딕셔너리 변환 했으면, 각 필요한 column 설정해서 데이터 Post
@app.route('/Scania/Etc', methods=['POST'])
def Post_Scania_Etc():
    global scania_etc_items_dict
    data = request.json
    print(scania_etc_items_dict)
    # 각 column의 이름 정해줘야됨

    for item in data:
        Market_Etc_ID, Name, Image_url, Description, Price, Registration_date, Count = item.values()
        scania_etc_items_dict[Market_Etc_ID] = {
            "Market_Etc_ID": Market_Etc_ID,
            "Name": Name,
            "Image_url": Image_url,
            "Description": Description,
            "Price": Price,
            "Registration_date": Registration_date,
            "Count": Count
        }
    return jsonify({"message": "Items updated successfully"}), 200


# Post한 데이터 GET 해와서 json 형식으로 변환.
@app.route('/Scania/Etc', methods=['GET'])
def Get_Scania_Etc():
    return jsonify(scania_etc_items_dict), 200


aurora_etc_items_dict = get_aurora_etc_items()


# Scania Use 데이터
# 쿼리로 불러오는 데이터 딕셔너리 변환 했으면, 각 필요한 column 설정해서 데이터 Post
@app.route('/Aurora/Etc', methods=['POST'])
def Post_Aurora_Etc():
    global aurora_etc_items_dict
    data = request.json
    print(aurora_etc_items_dict)
    # 각 column의 이름 정해줘야됨

    for item in data:
        Market_Etc_ID, Name, Image_url, Description, Price, Registration_date, Count = item.values()
        aurora_etc_items_dict[Market_Etc_ID] = {
            "Market_Etc_ID": Market_Etc_ID,
            "Name": Name,
            "Image_url": Image_url,
            "Description": Description,
            "Price": Price,
            "Registration_date": Registration_date,
            "Count": Count
        }
    return jsonify({"message": "Items updated successfully"}), 200


# Post한 데이터 GET 해와서 json 형식으로 변환.
@app.route('/Aurora/Etc', methods=['GET'])
def Get_Aurora_Etc():
    return jsonify(aurora_etc_items_dict), 200


# 각 페이지 불러오기
@app.route('/')
def index():
    return render_template('Weapon_scania.html')

@app.route('/Base_Use.html')
def Base_Use():
    return render_template('Base_Use.html')

@app.route('/Base_Etc.html')
def Base_Etc():
    return render_template('Base_Etc.html')

@app.route('/Base_Weapon.html')
def Base_Weapon():
    return render_template('Base_Weapon.html')

@app.route('/Weapon_scania.html')
def Weapon_scania():
    return render_template('Weapon_scania.html')


@app.route('/Armor_scania.html')
def Armor_scania():
    return render_template('Armor_scania.html')


@app.route('/Use_scania.html')
def Use_scania():
    return render_template('Use_scania.html')


@app.route('/Etc_scania.html')
def Etc_scania():
    return render_template('Etc_scania.html')


@app.route('/Weapon_Aurora.html')
def Weapon_Aurora():
    return render_template('Weapon_Aurora.html')


@app.route('/Armor_Aurora.html')
def Armor_Aurora():
    return render_template('Armor_Aurora.html')


@app.route('/Use_Aurora.html')
def Use_Aurora():
    return render_template('Use_Aurora.html')


@app.route('/Etc_Aurora.html')
def Etc_Aurora():
    return render_template('Etc_Aurora.html')


if __name__ == '__main__':
    app.run('0.0.0.0', port=5000, debug=True)

# connection 해왔으면, 마지막에 close 해줘야함
