var myDataTable; // DataTables 인스턴스를 저장할 전역 변수

function showWeaponItem(response) {
    let newData = [];
    // console.log(response);
    // 테이블에 데이터 넣는 코드
    for (let key in response) {
        if (response.hasOwnProperty(key)) {
            let item = response[key];
            newData.push([
                `<img src="${item.Image_url}" alt="Item Image" width="30px" height="30px">`,
                item.Name,
                item.Description
            ]);
            // console.log(item.Description);
        }
    }
    // console.log(newData);

    // 충돌 해결
    if (myDataTable) {
        myDataTable.destroy();

    }
    myDataTable = new simpleDatatables.DataTable(document.getElementById('datatablesSimple'), {
        data: {
            headings: [
                "Image_url",
                "Name",
                "Description"
            ],
            data: newData,
        }

    });
    $('table').first().attr('id', 'datatablesSimple');
}


function fetchItems() {
    $.ajax({
        url: '/Base/etc',
        type: 'GET',
        success: function (response) {
            allData = response;
            showWeaponItem(response);
        },
        error: function (error) {
            console.log(error);
        }
    });

}


$(document).ready(function () {

    // 데이터 보여주기
    fetchItems();


});
