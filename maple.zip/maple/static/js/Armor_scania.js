var myDataTable; // DataTables 인스턴스를 저장할 전역 변수
var allData = []; // 서버에서 가져온 전체 데이터 저장

function showArmorItem(response) {
    let newData = [];
    console.log(response);
    // 테이블에 데이터 넣는 코드
    for (let key in response) {
        if (response.hasOwnProperty(key)) {
            let item = response[key];
            newData.push([
                `<img src="${item.Image}" alt="Item Image" width="30px" height="30px">`,
                item.name,
                item.Price,
                item.Class,
                item.Star_force,
                item.STR_,
                item.DEX_,
                item.INT_,
                item.LUK_,
                item.All_stat,
                item.Attack_Power,
                item.Magic_Att,
                item.Rank_,
                item.Potential1,
                item.Potential2,
                item.Potential3,
                item.Add_Rank,
                item.Add_Potential1,
                item.Add_Potential2,
                item.Add_Potential3,
            ]);
            // console.log(item.Description);
        }
    }
    console.log(newData);

    // 충돌 해결
    if (myDataTable) {
        myDataTable.destroy();
    }
    myDataTable = new simpleDatatables.DataTable(document.getElementById('datatablesSimple'), {
        data: {
            headings: [
                "Image",
                "name",
                "Price",
                "Class",
                "Star_force",
                "STR_",
                "DEX_",
                "INT_",
                "LUK_",
                "All_stat",
                "Attack_Power",
                "Magic_Att",
                "Rank_",
                "Potential1",
                "Potential2",
                "Potential3",
                "Add_Rank",
                "Add_Potential1",
                "Add_Potential2",
                "Add_Potential3"
            ],
            data: newData
        }

    });

    $('table').first().attr('id', 'datatablesSimple');

}

function filterData() {
    var PriceValue = $('#price').val() ? parseInt($('#price').val(), 10) : null;
    var PriceValue2 = $('#price2').val() ? parseInt($('#price2').val(), 10) : null;
    var starForceValue = $('#starforce').val() ? parseInt($('#starforce').val(), 10) : null;
    var RankType = $('#Potential_Rank').val();
    var AddRankType = $('#AddRank').val();

    var filteredData = [];
    for (let key in allData) {
        if (allData.hasOwnProperty(key)) {
            let item = allData[key];
            var priceInRow = parseInt(item.Price, 10) || 0;
            var starForceInRow = parseInt(item.Star_force, 10) || 0;
            var rankInRow = item.Rank_;
            var addRankInRow = item.Add_Rank;

            var priceCondition = (PriceValue === null || priceInRow >= PriceValue) && (PriceValue2 === null || priceInRow <= PriceValue2);
            var starForceCondition = (starForceValue === null || starForceInRow === starForceValue);
            var rankCondition = (RankType === "" || rankInRow === RankType);
            var addRankCondition = (AddRankType === "" || addRankInRow === AddRankType);

            if (priceCondition && starForceCondition && rankCondition && addRankCondition) {
                filteredData.push(item);
            }
        }
    }

    showArmorItem(filteredData);
}

function fetchItems() {
    $.ajax({
        url: '/Scania/Armor',
        type: 'GET',
        success: function (response) {
            allData = response;

            showArmorItem(response);
        },
        error: function (error) {
            console.log(error);
        }
    });
}

// 페이지 로드 시 호출되는 함수
$(document).ready(function () {

    fetchItems();

    // 필터링
    $('#search-button').on('click', function () {
        filterData();
    });

});

