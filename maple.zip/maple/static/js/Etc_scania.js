var myLineChart; // 차트 인스턴스를 저장할 전역 변수

function drawChart(name, response) {
    document.getElementById('chartsSection').style.display = 'block';

    let itemsArray = Object.values(response);
    // console.log(response);

    // 이름과 일치하는 아이템만 필터링
    let filteredItems = itemsArray.filter(item => item.Name === name);
    console.log(filteredItems);

    // 날짜별로 그룹화하고 평균 가격 계산
    let groupedByDate = {};
    filteredItems.forEach(item => {
        let date = item.Registration_date;

        if (!groupedByDate[date]) {
            groupedByDate[date] = [];
        }
        groupedByDate[date].push(item.Price);
    });
    let chartLabels = Object.keys(groupedByDate).sort((a, b) => new Date(a) - new Date(b));
    let chartData = chartLabels.map(date => {
        let prices = groupedByDate[date];
        let sum = prices.reduce((a, b) => a + b, 0);
        return (sum / prices.length).toFixed(2); // 평균 가격을 소수점 둘째 자리까지 계산
    });
    // Chart.js 차트 구성과 데이터 설정
    var ctx = document.getElementById("myAreaChart").getContext('2d');
    if (myLineChart) {
        myLineChart.data.labels = chartLabels;
        myLineChart.data.datasets[0].data = chartData;
        myLineChart.data.datasets[0].label = name + ' Average Price';
        myLineChart.update();
    } else {
        myLineChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: chartLabels,
                datasets: [{
                    label: name + ' Average Price',
                    data: chartData,
                    borderColor: 'rgb(75, 192, 192)',
                    fill: false
                }]
            },
            options: {
                scales: {
                    x: {
                        type: 'time',
                        time: {
                            unit: 'day',
                            tooltipFormat: 'll'
                        }
                    },
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    let descriptionElement = document.getElementById('Etc-item-description');
    if (descriptionElement) {
        let description = "";
        for (let i = 0; i < filteredItems.length; i++) {
            if (filteredItems[i].Name === name) {
                description = filteredItems[i].Description;
                break;
            }
        }
        console.log(description);
        descriptionElement.innerText = description;
    }
}


var myDataTable; // DataTables 인스턴스를 저장할 전역 변수
function showEtcItem(response) {
    let newData = [];
    console.log(response);
    // 테이블에 데이터 넣는 코드
    for (let key in response) {
        if (response.hasOwnProperty(key)) {
            let item = response[key];
            newData.push([
                `<img src="${item.Image_url}" alt="Item Image" width="30px" height="30px">`,
                item.Name,
                item.Price,
                item.Registration_date,
                item.Count
            ]);
            // console.log(item.Description);
        }
    }
    // 충돌 해결
    if (myDataTable) {
        myDataTable.destroy();
    }
    myDataTable = new simpleDatatables.DataTable(document.getElementById('datatablesSimple'), {
        data: {
            headings: ["IMG", "Name", "Price", "Registration Date", "Count"],
            data: newData
        }

    });

    // 각 row 클릭할 시, draw chart()
    document.querySelector('#datatablesSimple tbody').addEventListener('click', function (e) {
        var clickedRow = e.target.closest('tr');
        if (clickedRow) {
            var tdElements = clickedRow.children; // clickedRow의 모든 자식 요소를 가져옵니다.
            var values = Array.from(tdElements).map(td => td.textContent.trim()); // 각 td 요소의 텍스트를 추출합니다.

            console.log(values); // 각 td 요소의 값들을 배열로 출력합니다.
            drawChart(values[1], response);
        }
    });


}

function fetchItems() {
    $.ajax({
        url: '/Scania/Etc',
        type: 'GET',
        success: function (response) {
            showEtcItem(response);
        },
        error: function (error) {
            console.log(error);
        }
    });
}

// 페이지 로드 시 호출되는 함수
$(document).ready(function () {
    document.getElementById('chartsSection').style.display = 'none';

    fetchItems();

});

