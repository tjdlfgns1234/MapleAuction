var myDataTable; // DataTables 인스턴스를 저장할 전역 변수
var allData = []; // 서버에서 가져온 전체 데이터 저장

function showWeaponItem(response) {
    let newData = [];
    // console.log(response);
    // 테이블에 데이터 넣는 코드
    for (let key in response) {
        if (response.hasOwnProperty(key)) {
            let item = response[key];
            newData.push([
                `<img src="${item.Image}" alt="Item Image" width="30px" height="30px">`,
                item.name,
                item.Price,
                item.Class,
                item.Star_force,
                item.STR_,
                item.DEX_,
                item.INT_,
                item.LUK_,
                item.All_stat,
                item.Attack_Power,
                item.Magic_Att,
                item.Damage,
                item.Boss_Damage,
                item.Rank,
                item.Potential1,
                item.Potential2,
                item.Potential3,
                item.Add_Rank,
                item.Add_Potential1,
                item.Add_Potential2,
                item.Add_Potential3,
            ]);
            // console.log(item.Description);
        }
    }
    // console.log(newData);

    // 충돌 해결
    if (myDataTable) {
        myDataTable.destroy();

    }
    myDataTable = new simpleDatatables.DataTable(document.getElementById('datatablesSimple'), {
        data: {
            headings: [
                "Image",
                "name",
                "Price",
                "Class",
                "Star_force",
                "STR_",
                "DEX_",
                "INT_",
                "LUK_",
                "All_stat",
                "Attack_Power",
                "Magic_Att",
                "Damage",
                "Boss_Damage",
                "Rank",
                "Potential1",
                "Potential2",
                "Potential3",
                "Add_Rank",
                "Add_Potential1",
                "Add_Potential2",
                "Add_Potential3"
            ],
            data: newData,
        }

    });
    $('table').first().attr('id', 'datatablesSimple');

}

function filterData() {
    var PriceValue = $('#price').val() ? parseInt($('#price').val(), 10) : null;
    var PriceValue2 = $('#price2').val() ? parseInt($('#price2').val(), 10) : null;
    var starForceValue = $('#starforce').val() ? parseInt($('#starforce').val(), 10) : null;
    var RankType = $('#Potential_Rank').val();
    var AddRankType = $('#AddRank').val();

    var filteredData = [];
    for (let key in allData) {
        if (allData.hasOwnProperty(key)) {
            let item = allData[key];
            var priceInRow = parseInt(item.Price, 10) || 0;
            var starForceInRow = parseInt(item.Star_force, 10) || 0;
            var rankInRow = item.Rank;
            var addRankInRow = item.Add_Rank;

            var priceCondition = (PriceValue === null || priceInRow >= PriceValue) && (PriceValue2 === null || priceInRow <= PriceValue2);
            var starForceCondition = (starForceValue === null || starForceInRow === starForceValue);
            var rankCondition = (RankType === "" || rankInRow === RankType);
            var addRankCondition = (AddRankType === "" || addRankInRow === AddRankType);

            if (priceCondition && starForceCondition && rankCondition && addRankCondition) {
                filteredData.push(item);
            }
        }
    }
    // $.ajax({
    //     url: '/Scania/post/Weapon', // 서버의 URL
    //     type: 'POST', // 요청 방식
    //     contentType: 'application/json', // 요청 데이터 타입
    //     data: JSON.stringify(filteredData), // 서버로 보낼 데이터
    //     success: function (response) {
    //         // 요청이 성공했을 때 실행될 함수
    //         console.log('Success:', response);
    //     },
    //     error: function (xhr, status, error) {
    //         // 요청이 실패했을 때 실행될 함수
    //         console.error('Error:', error);
    //     }
    // });
    showWeaponItem(filteredData);
}

function fetchItems() {

    $.ajax({
        url: '/Scania/Weapon',
        type: 'GET',
        success: function (response) {
            allData = response;
            showWeaponItem(response);
        },
        error: function (error) {
            console.log(error);
        }
    });

}


$(document).ready(function () {

    // 데이터 보여주기
    fetchItems();

    // 필터링
    $('#search-button').on('click', function () {
        filterData();
    });


});
