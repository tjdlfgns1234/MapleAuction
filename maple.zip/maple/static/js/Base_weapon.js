var myDataTable; // DataTables 인스턴스를 저장할 전역 변수

function showWeaponItem(response) {
    let newData = [];
    // console.log(response);
    // 테이블에 데이터 넣는 코드
    for (let key in response) {
        if (response.hasOwnProperty(key)) {
            let item = response[key];
            newData.push([
                `<img src="${item.Image_url}" alt="Item Image" width="30px" height="30px">`,
                item.name,
                item.STR_,
                item.DEX_,
                item.INT_,
                item.LUK_,
                item.Attack_Power,
                item.Magic_Att,
                item.Boss_Damage,
                item.Ignored_DEF
            ]);
            // console.log(item.Description);
        }
    }
    // console.log(newData);

    // 충돌 해결
    if (myDataTable) {
        myDataTable.destroy();

    }
    myDataTable = new simpleDatatables.DataTable(document.getElementById('datatablesSimple'), {
        data: {
            headings: [
                "Image_url",
                "name",
                "STR_",
                "DEX_",
                "INT_",
                "LUK_",
                "Attack_Power",
                "Magic_Att",
                "Boss_Damage",
                "Ignored_DEF"
            ],
            data: newData,
        }

    });
    $('table').first().attr('id', 'datatablesSimple');
}


function fetchItems() {
    $.ajax({
        url: '/Base/Weapon',
        type: 'GET',
        success: function (response) {
            showWeaponItem(response);
        },
        error: function (error) {
            console.log(error);
        }
    });

}


$(document).ready(function () {

    // 데이터 보여주기
    fetchItems();


});
