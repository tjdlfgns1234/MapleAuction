# db/database.py
import pymysql


# db 연동
def connect_db():
    return pymysql.connect(port=52368, host='43.201.69.120', user='Tomntoms', password='1qaz1qaz', db='maple',
                           charset='utf8')


def get_base_weapon():
    conn = connect_db()
    cur = conn.cursor()
    sql = ("select B.Base_Status_ID AS Base_Status_ID, W.Image_url AS Image_url, B.Name AS name, B.Attack_Power AS Attack_Power, "
           "B.Magic_Att AS Magic_Att, B.Boss_Damage AS Boss_Damage, B.Ignored_DEF AS Ignored_DEF, B.STR_ AS STR_, B.DEX_ AS DEX_, B.INT_ AS INT_, B.LUK_ AS LUK_"
           " from Weapon_Base_Status B "
           " Join Weapon W ON W.Weapon_ID = B.Weapon_ID; "
           )
    cur.execute(sql)
    items_dict = {}
    for item in cur:
        Base_Status_ID, Image_url, name, STR_, DEX_, INT_, LUK_, Attack_Power, Magic_Att, Boss_Damage, Ignored_DEF = item
        # 각 column의 이름 정해줘야됨
        items_dict[Base_Status_ID] = {"Image_url": Image_url,
                                      "name": name,
                                      "STR_": STR_,
                                      "DEX_": DEX_,
                                      "INT_": INT_,
                                      "LUK_": LUK_,
                                      "Attack_Power": Attack_Power,
                                      "Magic_Att": Magic_Att,
                                      "Boss_Damage": Boss_Damage,
                                      "Ignored_DEF": Ignored_DEF
                                      }
    # print(items_dict)
    conn.close()
    return items_dict


def get_base_use():
    conn = connect_db()
    cur = conn.cursor()
    sql = (" SELECT * FROM Usable_Item ")
    cur.execute(sql)
    items_dict = {}
    for item in cur:
        Use_ID, Name, Image_url, Description = item
        # 각 column의 이름 정해줘야됨
        items_dict[Use_ID] = {"Use_ID": Use_ID,
                              "Name": Name,
                              "Image_url": Image_url,
                              "Description": Description,
                              }
    # print(items_dict)
    conn.close()
    return items_dict


def get_base_etc():
    conn = connect_db()
    cur = conn.cursor()
    sql = (" SELECT * FROM Etc_Item ")
    cur.execute(sql)
    items_dict = {}
    for item in cur:
        Etc_ID, Name, Image_url, Description = item
        # 각 column의 이름 정해줘야됨
        items_dict[Etc_ID] = {"Etc_ID": Etc_ID,
                              "Name": Name,
                              "Image_url": Image_url,
                              "Description": Description,
                              }
    # print(items_dict)
    conn.close()
    return items_dict


def get_aurora_weapon():
    conn = connect_db()
    cur = conn.cursor()

    # select 후에 받아온 값이 tuple 형태이기 때문에
    sql = (
        "SELECT "
        "S.Market_Weapon_ID AS Market_Weapon_ID, "
        "W.Image_url AS  Image, "
        "W.name AS name, "
        "S.Price AS Price, "
        "W.Class AS Class, "
        "S.Star_force AS Star_force, "
        "O.Attack_Power AS Attack_Power, "
        "O.Magic_Att AS Magic_Att, "
        "O.Damage AS Damage , "
        "O.Boss_Damage AS Boss_Damage, "
        "O.STR_ AS STR_, "
        "O.DEX_ AS DEX_, "
        "O.Int_ AS Int_, "
        "O.LUK_ AS LUK_, "
        "O.All_stat AS All_stat, "
        "P.Rank_ AS Rank_, "
        "P.Potential1 AS Potential1, "
        "P.Potential2 AS Potential2, "
        "P.Potential3 AS Potential3, "
        "P.Add_Rank AS  Add_Rank, "
        "P.Add_Potential1 AS Add_Potential1, "
        "P.Add_Potential2 AS Add_Potential2, "
        "P.Add_Potential3 AS Add_Potential3 "
        "FROM "
        "Weapons_For_Sale S "
        "INNER JOIN "
        "Weapon W ON S.Weapon_ID = W.Weapon_ID "
        "INNER JOIN "
        "Weapon_Additional_Option O ON S.Market_Weapon_ID = O.Market_Weapon_ID "
        "INNER JOIN "
        "Weapons_Potential P ON S.Market_Weapon_ID = P.Market_Weapon_ID "
        "WHERE "
        "S.World_ID = 2"
    )

    cur.execute(sql)

    #     sql = ("SELECT AAO_Market_Armor_ID, Image, name, Price, Class, STR_, DEX_, INT_, LUK_, All_stat, Attack_Power,
    #     Magic_Att, Potential1, Potential2, Potential3, Add_Potential1, Add_Potential2, Add_Potential3 "
    # 딕셔너리로 변환
    items_dict = {}
    for item in cur:
        Market_Weapon_ID, Image, name, Price, Class, Star_force, STR_, DEX_, INT_, LUK_, All_stat, Attack_Power, Magic_Att, Damage, Boss_Damage, Rank_, Potential1, Potential2, Potential3, Add_Rank, Add_Potential1, Add_Potential2, Add_Potential3 = item
        # 각 column의 이름 정해줘야됨
        items_dict[Market_Weapon_ID] = {"Image": Image,
                                        "name": name,
                                        "Price": Price,
                                        "Class": Class,
                                        "Star_force": Star_force,
                                        "STR_": STR_,
                                        "DEX_": DEX_,
                                        "INT_": INT_,
                                        "LUK_": LUK_,
                                        "All_stat": All_stat,
                                        "Attack_Power": Attack_Power,
                                        "Magic_Att": Magic_Att,
                                        "Damage": Damage,
                                        "Boss_Damage": Boss_Damage,
                                        "Rank": Rank_,
                                        "Potential1": Potential1,
                                        "Potential2": Potential2,
                                        "Potential3": Potential3,
                                        "Add_Rank": Add_Rank,
                                        "Add_Potential1": Add_Potential1,
                                        "Add_Potential2": Add_Potential2,
                                        "Add_Potential3": Add_Potential3
                                        }
    # print(items_dict)
    conn.close()
    return items_dict


def get_scania_weapon():
    conn = connect_db()
    cur = conn.cursor()

    # select 후에 받아온 값이 tuple 형태이기 때문에
    sql = (
        "SELECT "
        "S.Market_Weapon_ID AS Market_Weapon_ID, "
        "W.Image_url AS  Image, "
        "W.name AS name, "
        "S.Price AS Price, "
        "W.Class AS Class, "
        "S.Star_force AS Star_force, "
        "O.Attack_Power AS Attack_Power, "
        "O.Magic_Att AS Magic_Att, "
        "O.Damage AS Damage , "
        "O.Boss_Damage AS Boss_Damage, "
        "O.STR_ AS STR_, "
        "O.DEX_ AS DEX_, "
        "O.Int_ AS Int_, "
        "O.LUK_ AS LUK_, "
        "O.All_stat AS All_stat, "
        "P.Rank_ AS Rank_, "
        "P.Potential1 AS Potential1, "
        "P.Potential2 AS Potential2, "
        "P.Potential3 AS Potential3, "
        "P.Add_Rank AS  Add_Rank, "
        "P.Add_Potential1 AS Add_Potential1, "
        "P.Add_Potential2 AS Add_Potential2, "
        "P.Add_Potential3 AS Add_Potential3 "
        "FROM "
        "Weapons_For_Sale S "
        "INNER JOIN "
        "Weapon W ON S.Weapon_ID = W.Weapon_ID "
        "INNER JOIN "
        "Weapon_Additional_Option O ON S.Market_Weapon_ID = O.Market_Weapon_ID "
        "INNER JOIN "
        "Weapons_Potential P ON S.Market_Weapon_ID = P.Market_Weapon_ID "
        "WHERE "
        "S.World_ID = 1"
    )

    cur.execute(sql)

    #     sql = ("SELECT AAO_Market_Armor_ID, Image, name, Price, Class, STR_, DEX_, INT_, LUK_, All_stat, Attack_Power,
    #     Magic_Att, Potential1, Potential2, Potential3, Add_Potential1, Add_Potential2, Add_Potential3 "
    # 딕셔너리로 변환
    items_dict = {}
    for item in cur:
        Market_Weapon_ID, Image, name, Price, Class, Star_force, STR_, DEX_, INT_, LUK_, All_stat, Attack_Power, Magic_Att, Damage, Boss_Damage, Rank_, Potential1, Potential2, Potential3, Add_Rank, Add_Potential1, Add_Potential2, Add_Potential3 = item
        # 각 column의 이름 정해줘야됨
        items_dict[Market_Weapon_ID] = {"Image": Image,
                                        "name": name,
                                        "Price": Price,
                                        "Class": Class,
                                        "Star_force": Star_force,
                                        "STR_": STR_,
                                        "DEX_": DEX_,
                                        "INT_": INT_,
                                        "LUK_": LUK_,
                                        "All_stat": All_stat,
                                        "Attack_Power": Attack_Power,
                                        "Magic_Att": Magic_Att,
                                        "Damage": Damage,
                                        "Boss_Damage": Boss_Damage,
                                        "Rank": Rank_,
                                        "Potential1": Potential1,
                                        "Potential2": Potential2,
                                        "Potential3": Potential3,
                                        "Add_Rank": Add_Rank,
                                        "Add_Potential1": Add_Potential1,
                                        "Add_Potential2": Add_Potential2,
                                        "Add_Potential3": Add_Potential3
                                        }
    # print(items_dict)
    conn.close()
    return items_dict


# scania armor
def get_scania_armor():
    conn = connect_db()
    cur = conn.cursor()

    # select 후에 받아온 값이 tuple 형태이기 때문에

    sql = (
        "SELECT AAO_Market_Armor_ID, Image, name, Price, Class, Star_force, STR_, DEX_, INT_, LUK_, All_stat, Attack_Power, Magic_Att, Rank_, Potential1, Potential2, Potential3, Add_Rank, Add_Potential1, Add_Potential2, Add_Potential3 "
        " from ( SELECT AAO_Market_Armor_ID, A.Image_url AS Image, A.name,  AFS.Price, A.Class, AFS.Star_force, AFS.STR_, "
        "AFS.DEX_, AFS.INT_, AFS.LUK_, AFS.All_stat, AFS.Attack_Power, AFS.Magic_Att "
        "from "
        "("
        "SELECT AF.Armor_ID, AF.Market_Armor_ID, AAO.Market_Armor_ID AS AAO_Market_Armor_ID, AF.World_ID,"
        " AF.Price, AF.Star_force, AAO.STR_, AAO.DEX_, AAO.INT_, AAO.LUK_, AAO.All_stat, AAO.Attack_Power, AAO.Magic_Att "
        "FROM Armor_For_Sale AS AF "
        "JOIN Armor_Additional_Option AS AAO ON AAO.Market_Armor_ID = AF.Market_Armor_ID) "
        "AS AFS "
        "JOIN Armor AS A ON A.Armor_ID = AFS.Armor_ID "
        "Where AFS.World_ID = 1) AS AFSP "
        "JOIN Armor_Potential AS AP ON AP.Market_Armor_ID = AFSP.AAO_Market_Armor_ID;")

    # sql = (" SELECT Market_Armor_ID, Image, name, Price, Class, Star_force, STR_, DEX_, INT_, LUK_, All_stat, Attack_Power, "
    #        " Magic_Att, Rank_, Potential1, Potential2, Potential3, Add_Rank, Add_Potential1, Add_Potential2, Add_Potential3 WHERE World_ID = 1 ")

    cur.execute(sql)

    # 딕셔너리로 변환
    items_dict = {}
    for item in cur:
        AAO_Market_Armor_ID, Image, name, Price, Class, Star_force, STR_, DEX_, INT_, LUK_, All_stat, Attack_Power, Magic_Att, Rank_, Potential1, Potential2, Potential3, Add_Rank, Add_Potential1, Add_Potential2, Add_Potential3 = item
        # 각 column의 이름 정해줘야됨
        items_dict[AAO_Market_Armor_ID] = {"Image": Image,
                                           "name": name,
                                           "Price": Price,
                                           "Class": Class,
                                           "Star_force": Star_force,
                                           "STR_": STR_,
                                           "DEX_": DEX_,
                                           "INT_": INT_,
                                           "LUK_": LUK_,
                                           "All_stat": All_stat,
                                           "Attack_Power": Attack_Power,
                                           "Magic_Att": Magic_Att,
                                           "Rank_": Rank_,
                                           "Potential1": Potential1,
                                           "Potential2": Potential2,
                                           "Potential3": Potential3,
                                           "Add_Rank": Add_Rank,
                                           "Add_Potential1": Add_Potential1,
                                           "Add_Potential2": Add_Potential2,
                                           "Add_Potential3": Add_Potential3
                                           }

    # print(items_dict)
    conn.close()
    return items_dict


# aurora armor
def get_aurora_armor():
    conn = connect_db()
    cur = conn.cursor()

    # select 후에 받아온 값이 tuple 형태이기 때문에

    sql = (
        "SELECT AAO_Market_Armor_ID, Image, name, Price, Class, Star_force, STR_, DEX_, INT_, LUK_, All_stat, Attack_Power, Magic_Att, Rank_, Potential1, Potential2, Potential3, Add_Rank, Add_Potential1, Add_Potential2, Add_Potential3 "
        " from ( SELECT AAO_Market_Armor_ID, A.Image_url AS Image, A.name,  AFS.Price, A.Class, AFS.Star_force, AFS.STR_, "
        "AFS.DEX_, AFS.INT_, AFS.LUK_, AFS.All_stat, AFS.Attack_Power, AFS.Magic_Att "
        "from "
        "("
        "SELECT AF.Armor_ID, AF.Market_Armor_ID, AAO.Market_Armor_ID AS AAO_Market_Armor_ID, AF.World_ID,"
        " AF.Price, AF.Star_force, AAO.STR_, AAO.DEX_, AAO.INT_, AAO.LUK_, AAO.All_stat, AAO.Attack_Power, AAO.Magic_Att "
        "FROM Armor_For_Sale AS AF "
        "JOIN Armor_Additional_Option AS AAO ON AAO.Market_Armor_ID = AF.Market_Armor_ID) "
        "AS AFS "
        "JOIN Armor AS A ON A.Armor_ID = AFS.Armor_ID "
        "Where AFS.World_ID = 2) AS AFSP "
        "JOIN Armor_Potential AS AP ON AP.Market_Armor_ID = AFSP.AAO_Market_Armor_ID;")

    cur.execute(sql)

    #     sql = ("SELECT AAO_Market_Armor_ID, Image, name, Price, Class, STR_, DEX_, INT_, LUK_, All_stat, Attack_Power,
    #     Magic_Att, Potential1, Potential2, Potential3, Add_Potential1, Add_Potential2, Add_Potential3 "
    # 딕셔너리로 변환
    items_dict = {}
    for item in cur:
        AAO_Market_Armor_ID, Image, name, Price, Class, Star_force, STR_, DEX_, INT_, LUK_, All_stat, Attack_Power, Magic_Att, Rank_, Potential1, Potential2, Potential3, Add_Rank, Add_Potential1, Add_Potential2, Add_Potential3 = item
        # 각 column의 이름 정해줘야됨
        items_dict[AAO_Market_Armor_ID] = {"Image": Image,
                                           "name": name,
                                           "Price": Price,
                                           "Class": Class,
                                           "Star_force": Star_force,
                                           "STR_": STR_,
                                           "DEX_": DEX_,
                                           "INT_": INT_,
                                           "LUK_": LUK_,
                                           "All_stat": All_stat,
                                           "Attack_Power": Attack_Power,
                                           "Magic_Att": Magic_Att,
                                           "Rank_": Rank_,
                                           "Potential1": Potential1,
                                           "Potential2": Potential2,
                                           "Potential3": Potential3,
                                           "Add_Rank": Add_Rank,
                                           "Add_Potential1": Add_Potential1,
                                           "Add_Potential2": Add_Potential2,
                                           "Add_Potential3": Add_Potential3
                                           }

    # print(items_dict)
    conn.close()
    return items_dict


# 소비 아이템
def get_scania_use_items():
    conn = connect_db()
    cur = conn.cursor()

    # sql의 select 순서와 table에서 보여줄 이름의 순서가 같아야됨. 이거때매 차트 ㅈ같이됐음. 지금은 해결
    sql = ("SELECT us.Market_Use_ID as Market_Use_ID, "
           "ui.Name as Name, ui.Image_url as Image_url, "
           "ui.Description as Description, "
           " us.Price as Price,"
           "us.Registration_date as Registration_date, us.Count as Count "
           "FROM Usable_Item ui "
           "JOIN Usable_item_for_sale us ON ui.Use_ID = us.Use_ID "
           "WHERE us.Use_World_ID = 1;")

    cur.execute(sql)
    # select 후에 받아온 값이 tuple 형태이기 때문에
    # 딕셔너리로 변환
    items_dict = {}
    for item in cur:
        Market_Use_ID, Name, Image_url, Description, Price, Registration_date, Count = item
        # 각 column의 이름 정해줘야됨
        items_dict[Market_Use_ID] = {"Market_Use_ID": Market_Use_ID,
                                     "Name": Name,
                                     "Image_url": Image_url,
                                     "Description": Description,
                                     "Price": Price,
                                     "Registration_date": Registration_date,
                                     "Count": Count
                                     }

    # print(items_dict)
    conn.close()
    return items_dict


def get_aurora_use_items():
    conn = connect_db()
    cur = conn.cursor()

    # sql의 select 순서와 table에서 보여줄 이름의 순서가 같아야됨. 이거때매 차트 ㅈ같이됐음. 지금은 해결
    sql = ("SELECT us.Market_Use_ID as Market_Use_ID, "
           "ui.Name as Name, ui.Image_url as Image_url, "
           "ui.Description as Description, "
           " us.Price as Price,"
           "us.Registration_date as Registration_date, us.Count as Count "
           "FROM Usable_Item ui "
           "JOIN Usable_item_for_sale us ON ui.Use_ID = us.Use_ID "
           "WHERE us.Use_World_ID = 2;")

    cur.execute(sql)
    # select 후에 받아온 값이 tuple 형태이기 때문에
    # 딕셔너리로 변환
    items_dict = {}
    for item in cur:
        Market_Use_ID, Name, Image_url, Description, Price, Registration_date, Count = item
        # 각 column의 이름 정해줘야됨
        items_dict[Market_Use_ID] = {"Market_Use_ID": Market_Use_ID,
                                     "Name": Name,
                                     "Image_url": Image_url,
                                     "Description": Description,
                                     "Price": Price,
                                     "Registration_date": Registration_date,
                                     "Count": Count
                                     }

    # print(items_dict)
    conn.close()
    return items_dict


def get_scania_etc_items():
    conn = connect_db()
    cur = conn.cursor()

    # sql의 select 순서와 table에서 보여줄 이름의 순서가 같아야됨. 이거때매 차트 ㅈ같이됐음. 지금은 해결
    sql = ("SELECT es.Market_Etc_ID as Market_Etc_ID, "
           "ei.Name as Name, ei.Image_url as Image_url, "
           "ei.Description as Description, "
           " es.Price as Price,"
           "es.Registration_date as Registration_date, es.Count as Count "
           "FROM Etc_Item ei "
           "JOIN Etc_Item_for_sale es ON ei.Etc_ID = es.Etc_ID "
           "WHERE es.Etc_World_ID = 1;")

    cur.execute(sql)
    # select 후에 받아온 값이 tuple 형태이기 때문에
    # 딕셔너리로 변환
    items_dict = {}
    for item in cur:
        Market_Etc_ID, Name, Image_url, Description, Price, Registration_date, Count = item
        # 각 column의 이름 정해줘야됨
        items_dict[Market_Etc_ID] = {"Market_Etc_ID": Market_Etc_ID,
                                     "Name": Name,
                                     "Image_url": Image_url,
                                     "Description": Description,
                                     "Price": Price,
                                     "Registration_date": Registration_date,
                                     "Count": Count
                                     }

    # print(items_dict)
    conn.close()
    return items_dict


def get_aurora_etc_items():
    conn = connect_db()
    cur = conn.cursor()

    # sql의 select 순서와 table에서 보여줄 이름의 순서가 같아야됨. 이거때매 차트 ㅈ같이됐음. 지금은 해결
    sql = ("SELECT es.Market_Etc_ID as Market_Etc_ID, "
           "ei.Name as Name, ei.Image_url as Image_url, "
           "ei.Description as Description, "
           " es.Price as Price,"
           "es.Registration_date as Registration_date, es.Count as Count "
           "FROM Etc_Item ei "
           "JOIN Etc_Item_for_sale es ON ei.Etc_ID = es.Etc_ID "
           "WHERE es.Etc_World_ID = 2;")

    cur.execute(sql)
    # select 후에 받아온 값이 tuple 형태이기 때문에
    # 딕셔너리로 변환
    items_dict = {}
    for item in cur:
        Market_Etc_ID, Name, Image_url, Description, Price, Registration_date, Count = item
        # 각 column의 이름 정해줘야됨
        items_dict[Market_Etc_ID] = {"Market_Etc_ID": Market_Etc_ID,
                                     "Name": Name,
                                     "Image_url": Image_url,
                                     "Description": Description,
                                     "Price": Price,
                                     "Registration_date": Registration_date,
                                     "Count": Count
                                     }

    # print(items_dict)
    conn.close()
    return items_dict
